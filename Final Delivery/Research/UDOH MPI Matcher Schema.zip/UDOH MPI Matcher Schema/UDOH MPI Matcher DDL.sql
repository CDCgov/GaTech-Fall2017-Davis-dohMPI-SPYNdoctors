--
-- PostgreSQL database dump
--

-- Dumped from database version 9.4.10
-- Dumped by pg_dump version 9.4.10
-- Started on 2017-10-30 10:26:19

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- TOC entry 1 (class 3079 OID 11855)
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- TOC entry 2235 (class 0 OID 0)
-- Dependencies: 1
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- TOC entry 2 (class 3079 OID 67465)
-- Name: fuzzystrmatch; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS fuzzystrmatch WITH SCHEMA public;


--
-- TOC entry 2236 (class 0 OID 0)
-- Dependencies: 2
-- Name: EXTENSION fuzzystrmatch; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION fuzzystrmatch IS 'determine similarities and distance between strings';


--
-- TOC entry 3 (class 3079 OID 66154)
-- Name: hstore; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS hstore WITH SCHEMA public;


--
-- TOC entry 2237 (class 0 OID 0)
-- Dependencies: 3
-- Name: EXTENSION hstore; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION hstore IS 'data type for storing sets of (key, value) pairs';


SET search_path = public, pg_catalog;

SET default_with_oids = false;

--
-- TOC entry 179 (class 1259 OID 66295)
-- Name: address; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE address (
    id integer NOT NULL,
    identity_id integer,
    street1 character varying,
    street2 character varying,
    city character varying,
    county character varying,
    county_fips character varying,
    state character varying,
    state_fips character varying,
    country character varying,
    is_cass_certified boolean,
    zip5 character(5),
    zip4 character(4),
    datasource_id integer,
    created_on timestamp without time zone,
    last_changed_on timestamp without time zone
);


--
-- TOC entry 178 (class 1259 OID 66293)
-- Name: address_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE address_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 2238 (class 0 OID 0)
-- Dependencies: 178
-- Name: address_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE address_id_seq OWNED BY address.id;


--
-- TOC entry 181 (class 1259 OID 66311)
-- Name: deferredmatch; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE deferredmatch (
    id integer NOT NULL,
    identity_id_1 integer,
    identity_id_2 integer,
    score double precision,
    confidence double precision,
    created_on timestamp without time zone
);


--
-- TOC entry 180 (class 1259 OID 66309)
-- Name: deferredmatch_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE deferredmatch_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 2239 (class 0 OID 0)
-- Dependencies: 180
-- Name: deferredmatch_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE deferredmatch_id_seq OWNED BY deferredmatch.id;


--
-- TOC entry 183 (class 1259 OID 66329)
-- Name: demographics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE demographics (
    id integer NOT NULL,
    identity_id integer,
    is_mulitple_birth boolean,
    birth_order integer,
    birth_date character varying,
    birth_weight_grams integer,
    birth_facility_code character varying,
    gender character varying,
    is_deceased boolean,
    deceased_date character varying,
    adoption_status character varying,
    is_primary boolean,
    datasource_id integer,
    created_on timestamp without time zone,
    last_changed_on timestamp without time zone
);


--
-- TOC entry 182 (class 1259 OID 66327)
-- Name: demographics_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE demographics_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 2240 (class 0 OID 0)
-- Dependencies: 182
-- Name: demographics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE demographics_id_seq OWNED BY demographics.id;


--
-- TOC entry 185 (class 1259 OID 66345)
-- Name: identifier; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE identifier (
    id integer NOT NULL,
    identity_id integer,
    identifier_type character varying,
    identifier_value character varying,
    datasource_id integer,
    created_on timestamp without time zone,
    last_changed_on timestamp without time zone
);


--
-- TOC entry 184 (class 1259 OID 66343)
-- Name: identifier_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE identifier_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 2241 (class 0 OID 0)
-- Dependencies: 184
-- Name: identifier_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE identifier_id_seq OWNED BY identifier.id;


--
-- TOC entry 177 (class 1259 OID 66285)
-- Name: identifiertype; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE identifiertype (
    code character varying NOT NULL,
    description character varying
);


--
-- TOC entry 176 (class 1259 OID 66279)
-- Name: identity; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE identity (
    identity_id integer NOT NULL,
    mpi_id integer,
    created_on timestamp without time zone,
    last_changed_on timestamp without time zone
);


--
-- TOC entry 175 (class 1259 OID 66277)
-- Name: identity_identity_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE identity_identity_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 2242 (class 0 OID 0)
-- Dependencies: 175
-- Name: identity_identity_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE identity_identity_id_seq OWNED BY identity.identity_id;


--
-- TOC entry 187 (class 1259 OID 66366)
-- Name: log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE log (
    id integer NOT NULL,
    date timestamp without time zone,
    thread integer,
    level character varying(256),
    logger character varying(4096),
    message hstore,
    exception text
);


--
-- TOC entry 186 (class 1259 OID 66364)
-- Name: log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 2243 (class 0 OID 0)
-- Dependencies: 186
-- Name: log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE log_id_seq OWNED BY log.id;


--
-- TOC entry 193 (class 1259 OID 66429)
-- Name: name; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE name (
    id integer NOT NULL,
    identity_id integer,
    name_type character(12),
    name_word character varying,
    metaphone character varying,
    metaphone_alt character varying,
    datasource_id integer,
    created_on timestamp without time zone,
    last_changed_on timestamp without time zone
);


--
-- TOC entry 192 (class 1259 OID 66427)
-- Name: name_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE name_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 2244 (class 0 OID 0)
-- Dependencies: 192
-- Name: name_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE name_id_seq OWNED BY name.id;


--
-- TOC entry 188 (class 1259 OID 66375)
-- Name: nametype; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE nametype (
    code character varying NOT NULL,
    description character varying
);


--
-- TOC entry 195 (class 1259 OID 66450)
-- Name: nomatch; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE nomatch (
    id integer NOT NULL,
    identity_id_1 integer,
    identity_id_2 integer,
    created_on timestamp without time zone
);


--
-- TOC entry 194 (class 1259 OID 66448)
-- Name: nomatch_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE nomatch_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 2245 (class 0 OID 0)
-- Dependencies: 194
-- Name: nomatch_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE nomatch_id_seq OWNED BY nomatch.id;


--
-- TOC entry 191 (class 1259 OID 66399)
-- Name: pdnickname; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE pdnickname (
    peacock_id character varying NOT NULL,
    origin1 character varying,
    type1 character varying,
    gender1 character varying,
    name1 character varying,
    relflag character varying,
    relation character varying,
    origin2 character varying,
    type2 character varying,
    gender2 character varying,
    name2 character varying,
    derived character varying,
    fuzzy character varying,
    langflag character varying,
    usage1 character varying,
    bible1 character varying,
    english1 character varying,
    afram1 character varying,
    natam1 character varying,
    spanish1 character varying,
    basque1 character varying,
    catalan1 character varying,
    galician1 character varying,
    french1 character varying,
    german1 character varying,
    hindu1 character varying,
    russian1 character varying,
    persian1 character varying,
    arabic1 character varying,
    japanese1 character varying,
    chinese1 character varying,
    viet1 character varying,
    korean1 character varying,
    yiddish1 character varying,
    hebrew1 character varying,
    latin1 character varying,
    greek1 character varying,
    myth1 character varying,
    usage2 character varying,
    bible2 character varying,
    english2 character varying,
    afram2 character varying,
    natam2 character varying,
    spanish2 character varying,
    basque2 character varying,
    catalan2 character varying,
    galician2 character varying,
    french2 character varying,
    german2 character varying,
    hindu2 character varying,
    russian2 character varying,
    persian2 character varying,
    arabic2 character varying,
    japanese2 character varying,
    chinese2 character varying,
    viet2 character varying,
    korean2 character varying,
    yiddish2 character varying,
    hebrew2 character varying,
    latin2 character varying,
    greek2 character varying,
    myth2 character varying,
    realname character varying,
    reverse character varying
);


--
-- TOC entry 189 (class 1259 OID 66383)
-- Name: pdnicknameorigin; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE pdnicknameorigin (
    oid character varying NOT NULL,
    origin character varying
);


--
-- TOC entry 190 (class 1259 OID 66391)
-- Name: pdnicknameusage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE pdnicknameusage (
    uid character varying NOT NULL,
    usage character varying,
    notinuse character varying
);


--
-- TOC entry 197 (class 1259 OID 66468)
-- Name: phone; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE phone (
    id integer NOT NULL,
    identity_id integer,
    phone_number character varying,
    datasource_id integer,
    created_on timestamp without time zone,
    last_changed_on timestamp without time zone
);


--
-- TOC entry 196 (class 1259 OID 66466)
-- Name: phone_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE phone_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 2246 (class 0 OID 0)
-- Dependencies: 196
-- Name: phone_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE phone_id_seq OWNED BY phone.id;


--
-- TOC entry 2069 (class 2604 OID 66298)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY address ALTER COLUMN id SET DEFAULT nextval('address_id_seq'::regclass);


--
-- TOC entry 2070 (class 2604 OID 66314)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY deferredmatch ALTER COLUMN id SET DEFAULT nextval('deferredmatch_id_seq'::regclass);


--
-- TOC entry 2071 (class 2604 OID 66332)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY demographics ALTER COLUMN id SET DEFAULT nextval('demographics_id_seq'::regclass);


--
-- TOC entry 2072 (class 2604 OID 66348)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY identifier ALTER COLUMN id SET DEFAULT nextval('identifier_id_seq'::regclass);


--
-- TOC entry 2068 (class 2604 OID 66282)
-- Name: identity_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY identity ALTER COLUMN identity_id SET DEFAULT nextval('identity_identity_id_seq'::regclass);


--
-- TOC entry 2073 (class 2604 OID 66369)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY log ALTER COLUMN id SET DEFAULT nextval('log_id_seq'::regclass);


--
-- TOC entry 2074 (class 2604 OID 66432)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY name ALTER COLUMN id SET DEFAULT nextval('name_id_seq'::regclass);


--
-- TOC entry 2075 (class 2604 OID 66453)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY nomatch ALTER COLUMN id SET DEFAULT nextval('nomatch_id_seq'::regclass);


--
-- TOC entry 2076 (class 2604 OID 66471)
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY phone ALTER COLUMN id SET DEFAULT nextval('phone_id_seq'::regclass);


--
-- TOC entry 2082 (class 2606 OID 66303)
-- Name: pk_address; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY address
    ADD CONSTRAINT pk_address PRIMARY KEY (id);


--
-- TOC entry 2084 (class 2606 OID 66316)
-- Name: pk_deferredmatch; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY deferredmatch
    ADD CONSTRAINT pk_deferredmatch PRIMARY KEY (id);


--
-- TOC entry 2086 (class 2606 OID 66337)
-- Name: pk_demographics; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY demographics
    ADD CONSTRAINT pk_demographics PRIMARY KEY (id);


--
-- TOC entry 2088 (class 2606 OID 66353)
-- Name: pk_identifier; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY identifier
    ADD CONSTRAINT pk_identifier PRIMARY KEY (id);


--
-- TOC entry 2080 (class 2606 OID 66292)
-- Name: pk_identifiertype; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY identifiertype
    ADD CONSTRAINT pk_identifiertype PRIMARY KEY (code);


--
-- TOC entry 2078 (class 2606 OID 66284)
-- Name: pk_identity; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY identity
    ADD CONSTRAINT pk_identity PRIMARY KEY (identity_id);


--
-- TOC entry 2090 (class 2606 OID 66374)
-- Name: pk_log; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY log
    ADD CONSTRAINT pk_log PRIMARY KEY (id);


--
-- TOC entry 2100 (class 2606 OID 66437)
-- Name: pk_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY name
    ADD CONSTRAINT pk_name PRIMARY KEY (id);


--
-- TOC entry 2092 (class 2606 OID 66382)
-- Name: pk_nametype; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY nametype
    ADD CONSTRAINT pk_nametype PRIMARY KEY (code);


--
-- TOC entry 2102 (class 2606 OID 66455)
-- Name: pk_nomatch; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY nomatch
    ADD CONSTRAINT pk_nomatch PRIMARY KEY (id);


--
-- TOC entry 2098 (class 2606 OID 66406)
-- Name: pk_pdnickname; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY pdnickname
    ADD CONSTRAINT pk_pdnickname PRIMARY KEY (peacock_id);


--
-- TOC entry 2094 (class 2606 OID 66390)
-- Name: pk_pdnicknameorigin; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY pdnicknameorigin
    ADD CONSTRAINT pk_pdnicknameorigin PRIMARY KEY (oid);


--
-- TOC entry 2096 (class 2606 OID 66398)
-- Name: pk_pdnicknameusage; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY pdnicknameusage
    ADD CONSTRAINT pk_pdnicknameusage PRIMARY KEY (uid);


--
-- TOC entry 2104 (class 2606 OID 66476)
-- Name: pk_phone; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY phone
    ADD CONSTRAINT pk_phone PRIMARY KEY (id);


--
-- TOC entry 2109 (class 2606 OID 66354)
-- Name: fk_identifier_type_to_identifiertype; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY identifier
    ADD CONSTRAINT fk_identifier_type_to_identifiertype FOREIGN KEY (identifier_type) REFERENCES identifiertype(code);


--
-- TOC entry 2106 (class 2606 OID 66317)
-- Name: fk_identity_id_1_to_identity; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY deferredmatch
    ADD CONSTRAINT fk_identity_id_1_to_identity FOREIGN KEY (identity_id_1) REFERENCES identity(identity_id) ON DELETE CASCADE;


--
-- TOC entry 2117 (class 2606 OID 66456)
-- Name: fk_identity_id_1_to_identity; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY nomatch
    ADD CONSTRAINT fk_identity_id_1_to_identity FOREIGN KEY (identity_id_1) REFERENCES identity(identity_id) ON DELETE CASCADE;


--
-- TOC entry 2107 (class 2606 OID 66322)
-- Name: fk_identity_id_2_to_identity; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY deferredmatch
    ADD CONSTRAINT fk_identity_id_2_to_identity FOREIGN KEY (identity_id_2) REFERENCES identity(identity_id) ON DELETE CASCADE;


--
-- TOC entry 2118 (class 2606 OID 66461)
-- Name: fk_identity_id_2_to_identity; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY nomatch
    ADD CONSTRAINT fk_identity_id_2_to_identity FOREIGN KEY (identity_id_2) REFERENCES identity(identity_id) ON DELETE CASCADE;


--
-- TOC entry 2105 (class 2606 OID 66304)
-- Name: fk_identity_id_to_identity; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY address
    ADD CONSTRAINT fk_identity_id_to_identity FOREIGN KEY (identity_id) REFERENCES identity(identity_id) ON DELETE CASCADE;


--
-- TOC entry 2108 (class 2606 OID 66338)
-- Name: fk_identity_id_to_identity; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY demographics
    ADD CONSTRAINT fk_identity_id_to_identity FOREIGN KEY (identity_id) REFERENCES identity(identity_id) ON DELETE CASCADE;


--
-- TOC entry 2110 (class 2606 OID 66359)
-- Name: fk_identity_id_to_identity; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY identifier
    ADD CONSTRAINT fk_identity_id_to_identity FOREIGN KEY (identity_id) REFERENCES identity(identity_id) ON DELETE CASCADE;


--
-- TOC entry 2115 (class 2606 OID 66438)
-- Name: fk_identity_id_to_identity; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY name
    ADD CONSTRAINT fk_identity_id_to_identity FOREIGN KEY (identity_id) REFERENCES identity(identity_id) ON DELETE CASCADE;


--
-- TOC entry 2119 (class 2606 OID 66477)
-- Name: fk_identity_id_to_identity; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY phone
    ADD CONSTRAINT fk_identity_id_to_identity FOREIGN KEY (identity_id) REFERENCES identity(identity_id) ON DELETE CASCADE;


--
-- TOC entry 2116 (class 2606 OID 66443)
-- Name: fk_name_type_to_nametype; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY name
    ADD CONSTRAINT fk_name_type_to_nametype FOREIGN KEY (name_type) REFERENCES nametype(code);


--
-- TOC entry 2111 (class 2606 OID 66407)
-- Name: fk_origin1_to_pdnicknameorigin; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY pdnickname
    ADD CONSTRAINT fk_origin1_to_pdnicknameorigin FOREIGN KEY (origin1) REFERENCES pdnicknameorigin(oid);


--
-- TOC entry 2112 (class 2606 OID 66412)
-- Name: fk_origin2_to_pdnicknameorigin; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY pdnickname
    ADD CONSTRAINT fk_origin2_to_pdnicknameorigin FOREIGN KEY (origin2) REFERENCES pdnicknameorigin(oid);


--
-- TOC entry 2113 (class 2606 OID 66417)
-- Name: fk_usage1_to_pdnicknameusage; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY pdnickname
    ADD CONSTRAINT fk_usage1_to_pdnicknameusage FOREIGN KEY (usage1) REFERENCES pdnicknameusage(uid);


--
-- TOC entry 2114 (class 2606 OID 66422)
-- Name: fk_usage2_to_pdnicknameusage; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY pdnickname
    ADD CONSTRAINT fk_usage2_to_pdnicknameusage FOREIGN KEY (usage2) REFERENCES pdnicknameusage(uid);


-- Completed on 2017-10-30 10:26:19

--
-- PostgreSQL database dump complete
--

